IF font by Chris Hansen.

www.geocities.com/crizcrack666